Q-Uplink Mission Control evidence bundle. Private keys and API secrets are never included. See manifest.json for SHA-256 of every file and host details.
